

var onRun = function(context) {
	var sketch = context.api();
	var document = sketch.selectedDocument;
	var page = document.selectedPage;
	var selection = sketch.selectedDocument.selectedLayers;
	var artboardCount = 0

	selection.iterate(function(layer){	
		if(layer.isArtboard)
			var hasEasyBorder = false;
			layer.iterate(function(child){
				
				sketch.log(child.name);
				if(child.name == 'easyBorder_layer')
					hasEasyBorder=true;
			});

			if(!hasEasyBorder)
			{
				artboardCount++;
				var myFrame=layer.frame;
				var myStyle = new sketch.Style()
				myStyle.fills = [];
				myStyle.borders = ["#9AA0A6"];
				var easyBackground = layer.newShape({frame: new sketch.Rectangle(0, 0, myFrame.width, myFrame.height), style:myStyle});
				easyBackground.moveToFront();
				easyBackground.name = "easyBorder_layer";
			}
			else
				sketch.log("This already has a border");
			



		});

		sketch.message("Borders applied to "+artboardCount+" artboards");

};

